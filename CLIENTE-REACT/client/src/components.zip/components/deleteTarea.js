import React, { Component } from "react";
import "bootstrap/dist/css/bootstrap.min.css";

class DeleteTarea extends Component {
    render() {
        return (
            <div className="container">
                <h2> Borrar una tarea</h2>
            </div>
        );
    }
}

export default DeleteTarea;