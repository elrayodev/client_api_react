import React, { Component } from "react";
import "bootstrap/dist/css/bootstrap.min.css";

class CreateTarea extends Component {
    render() {
        return (
            <div className="container">
                <h2> Crear una tarea </h2>
            </div>
        );
    }
}

export default CreateTarea;